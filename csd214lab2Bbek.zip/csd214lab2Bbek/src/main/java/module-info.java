module com.example.csd214lab2bbek {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;

    opens com.example.csd214lab2bbek to javafx.fxml;
    exports com.example.csd214lab2bbek;
}