package com.example.csd214lab2bbek;

public class insurance {
    private int id;
    private String customer;




    public void setId(int id) {
        this.id = id;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public void setPolicy(int policy) {
        this.policy = policy;
    }

    private int policy;

    public insurance(int id, String customer, int policy) {
        this.id = id;
        this.customer = customer ;
        this.policy = policy ;

    }
    public int getId() {
        return id;
    }
    public String getCustomer() {
        return customer;
    }

    public int getpolicy() {
        return policy;
    }
}
